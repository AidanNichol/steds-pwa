'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'arrow-alt-down';
var width = 448;
var height = 512;
var ligatures = [];
var unicode = 'f354';
var svgPathData = ['M288,56V256H159.88V56a24,24,0,0,1,24-24H264A24,24,0,0,1,288,56Z', 'M408.93,297,241,473a24.09,24.09,0,0,1-34,0L39.07,297c-15.11-15.09-4.4-41,17-41H391.93C413.35,256,424,281.76,408.93,297Z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    ligatures,
    unicode,
    svgPathData
  ]};

exports.faArrowAltDown = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = ligatures;
exports.unicode = unicode;
exports.svgPathData = svgPathData;