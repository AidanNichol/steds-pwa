'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'arrow-alt-up';
var width = 448;
var height = 512;
var ligatures = [];
var unicode = 'f357';
var svgPathData = ['M160,456V256H288.11V456a24,24,0,0,1-24,24H184A24,24,0,0,1,160,456Z', 'M39.05,215,207,39a24.08,24.08,0,0,1,34,0L408.92,215c15.11,15.09,4.4,41-17,41H56.05C34.63,256,24,230.3,39.05,215Z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    ligatures,
    unicode,
    svgPathData
  ]};

exports.faArrowAltUp = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = ligatures;
exports.unicode = unicode;
exports.svgPathData = svgPathData;